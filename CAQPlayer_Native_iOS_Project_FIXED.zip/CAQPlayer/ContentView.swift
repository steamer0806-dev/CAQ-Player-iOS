import SwiftUI
import UniformTypeIdentifiers

struct ContentView: View {
    @EnvironmentObject private var store: QuizStore
    @State private var showingImporter = false

    var body: some View {
        NavigationStack {
            Group {
                if store.document == nil {
                    home
                } else if store.isSubmitted {
                    results
                } else {
                    quizScreen
                }
            }
            .padding()
            .background(Color(red: 0.035, green: 0.065, blue: 0.12).ignoresSafeArea())
            .navigationTitle("CAQ Player")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                if store.document != nil {
                    ToolbarItem(placement: .topBarTrailing) {
                        Button("Library") {
                            store.stopSpeaking()
                            store.document = nil
                            store.questions = []
                        }
                    }
                }
            }
            .fileImporter(isPresented: $showingImporter,
                          allowedContentTypes: [.caqQuiz, .zip],
                          allowsMultipleSelection: false) { result in
                switch result {
                case .success(let urls):
                    if let url = urls.first { store.importQuiz(from: url) }
                case .failure(let error):
                    store.errorMessage = error.localizedDescription
                }
            }
            .alert("CAQ Player", isPresented: Binding(
                get: { store.errorMessage != nil },
                set: { if !$0 { store.errorMessage = nil } }
            )) {
                Button("OK", role: .cancel) { store.errorMessage = nil }
            } message: {
                Text(store.errorMessage ?? "")
            }
        }
        .tint(Color.cyan)
    }

    private var home: some View {
        VStack(spacing: 22) {
            Spacer()
            Image(systemName: "graduationcap.fill")
                .font(.system(size: 62))
                .foregroundStyle(.cyan)
            Text("CAQ Quiz Player")
                .font(.largeTitle.bold())
            Text("Import your CAQ .quiz file and study anywhere, even offline.")
                .multilineTextAlignment(.center)
                .foregroundStyle(.secondary)
            Button {
                showingImporter = true
            } label: {
                Label("Choose .quiz file", systemImage: "folder")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(.cyan, in: RoundedRectangle(cornerRadius: 16))
                    .foregroundStyle(.black)
            }
            .padding(.top, 12)
            VStack(alignment: .leading, spacing: 10) {
                feature("Shuffle questions and answer choices", "shuffle")
                feature("Natural spoken questions and choices", "speaker.wave.2")
                feature("Instant red and green answer feedback", "checkmark.circle")
                feature("Score, review and retake", "chart.bar")
            }
            .padding()
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 18))
            Spacer()
        }
    }

    private var quizScreen: some View {
        VStack(spacing: 18) {
            HStack {
                Text(store.document?.fileName ?? "Quiz").font(.headline).lineLimit(1)
                Spacer()
                Text("\(store.currentIndex + 1) / \(store.questions.count)")
                    .foregroundStyle(.secondary).monospacedDigit()
            }
            ProgressView(value: Double(store.currentIndex + 1),
                         total: Double(max(store.questions.count, 1)))
                .tint(.cyan)

            if let question = store.currentQuestion {
                ScrollView {
                    VStack(alignment: .leading, spacing: 16) {
                        Text("QUESTION \(store.currentIndex + 1)")
                            .font(.caption.bold()).foregroundStyle(.cyan)
                        Text(question.text)
                            .font(.title3.bold())
                            .fixedSize(horizontal: false, vertical: true)

                        HStack {
                            Button { store.speakCurrentQuestion() } label: {
                                Label("Read aloud", systemImage: "speaker.wave.2.fill")
                            }
                            .buttonStyle(.bordered)
                            Button { store.stopSpeaking() } label: {
                                Label("Stop", systemImage: "stop.fill")
                            }
                            .buttonStyle(.bordered)
                            Toggle("Auto-read", isOn: $store.speechEnabled)
                                .labelsHidden()
                                .fixedSize()
                        }

                        ForEach(Array(question.options.enumerated()), id: \.offset) { index, option in
                            answerButton(option, index: index, question: question)
                        }

                        if let selected = selectedAnswer(at: store.currentIndex) {
                            let correctIndex = question.options.firstIndex(where: \.isCorrect) ?? 0
                            let isCorrect = question.options[selected].isCorrect
                            VStack(alignment: .leading, spacing: 5) {
                                Text(isCorrect ? "✓ Correct!" : "✕ Not quite.")
                                    .font(.headline)
                                if !isCorrect {
                                    Text("Correct answer: \(letter(correctIndex)). \(question.options[correctIndex].text)")
                                }
                            }
                            .foregroundStyle(isCorrect ? .green : .red)
                            .padding()
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background((isCorrect ? Color.green : Color.red).opacity(0.12),
                                        in: RoundedRectangle(cornerRadius: 14))
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
            }

            HStack {
                Button("Previous") { store.previous() }
                    .buttonStyle(.bordered)
                    .disabled(store.currentIndex == 0)
                Spacer()
                Button(store.currentIndex == store.questions.count - 1 ? "Submit" : "Next") {
                    store.next()
                }
                .buttonStyle(.borderedProminent)
            }
        }
    }

    @ViewBuilder
    private func answerButton(_ option: QuizOption, index: Int, question: QuizQuestion) -> some View {
        let selected = selectedAnswer(at: store.currentIndex)
        let correctIndex = question.options.firstIndex(where: \.isCorrect) ?? -1
        let isLocked = selected != nil
        let isWrongSelected = selected == index && !option.isCorrect
        let isCorrectOption = isLocked && index == correctIndex

        Button {
            store.choose(index)
        } label: {
            HStack(alignment: .top, spacing: 12) {
                Text(letter(index))
                    .font(.headline)
                    .frame(width: 30, height: 30)
                    .background(.white.opacity(0.12), in: RoundedRectangle(cornerRadius: 9))
                Text(option.text).multilineTextAlignment(.leading)
                Spacer(minLength: 0)
                if isCorrectOption { Image(systemName: "checkmark.circle.fill").foregroundStyle(.green) }
                else if isWrongSelected { Image(systemName: "xmark.circle.fill").foregroundStyle(.red) }
            }
            .padding(13)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(isCorrectOption ? Color.green.opacity(0.17) :
                        isWrongSelected ? Color.red.opacity(0.18) : Color.white.opacity(0.055),
                        in: RoundedRectangle(cornerRadius: 14))
            .overlay(RoundedRectangle(cornerRadius: 14)
                .stroke(isCorrectOption ? Color.green : isWrongSelected ? Color.red : Color.white.opacity(0.12),
                        lineWidth: isCorrectOption || isWrongSelected ? 2 : 1))
        }
        .buttonStyle(.plain)
        .disabled(isLocked)
    }

    private var results: some View {
        VStack(spacing: 18) {
            Image(systemName: "checkmark.seal.fill").font(.system(size: 54)).foregroundStyle(.green)
            Text("Exam completed").font(.largeTitle.bold())
            Text("\(store.score) / \(store.questions.count)")
                .font(.system(size: 48, weight: .bold, design: .rounded))
            Text("\(Int((Double(store.score) / Double(max(store.questions.count, 1))) * 100))%")
                .foregroundStyle(.secondary)
            List {
                ForEach(0..<store.questions.count, id: \.self) { index in
                    let question = store.questions[index]
                    let answer = selectedAnswer(at: index)
                    let correct = question.options.first(where: \.isCorrect)?.text ?? "Unknown"
                    VStack(alignment: .leading, spacing: 5) {
                        Text("\(index + 1). \(question.text)").font(.subheadline.bold())
                        Text(answer.map { question.options[$0].text } ?? "Not answered")
                            .foregroundStyle(answer.map { question.options[$0].isCorrect } == true ? .green : .red)
                        Text("Correct: \(correct)").font(.caption).foregroundStyle(.green)
                    }
                    .listRowBackground(Color.white.opacity(0.05))
                }
            }
            .scrollContentBackground(.hidden)
            Button {
                store.startNewAttempt()
            } label: {
                Label("Retake with new shuffle", systemImage: "shuffle")
                    .frame(maxWidth: .infinity).padding()
            }
            .buttonStyle(.borderedProminent)
        }
    }

    private func selectedAnswer(at index: Int) -> Int? {
        guard store.selectedAnswers.indices.contains(index) else { return nil }
        return store.selectedAnswers[index]
    }

    private func feature(_ title: String, _ icon: String) -> some View {
        Label(title, systemImage: icon).font(.subheadline)
    }

    private func letter(_ index: Int) -> String {
        String(UnicodeScalar(65 + index)!)
    }
}

extension UTType {
    static let caqQuiz = UTType(filenameExtension: "quiz") ?? .zip
}
