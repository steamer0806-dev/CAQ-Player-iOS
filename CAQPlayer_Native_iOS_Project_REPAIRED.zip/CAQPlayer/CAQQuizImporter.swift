import Foundation
import ZIPFoundation

enum CAQQuizImporter {
    static func load(from url: URL) throws -> QuizDocument {
        let access = url.startAccessingSecurityScopedResource()
        defer { if access { url.stopAccessingSecurityScopedResource() } }

        let archive = try Archive(url: url, accessMode: .read)
        guard let entry = archive["tempQuz.quz"] else {
            throw QuizImportError.missingQuestionFile
        }

        var data = Data()
        _ = try archive.extract(entry) { chunk in data.append(chunk) }
        guard let text = String(data: data, encoding: .utf8) else {
            throw QuizImportError.malformedQuestion("Question data is not UTF-8 text.")
        }

        let questions = parse(text)
        guard !questions.isEmpty else { throw QuizImportError.noQuestionsFound }
        return QuizDocument(fileName: url.deletingPathExtension().lastPathComponent,
                            questions: questions)
    }

    // CAQ records use >><< between questions and <> between fields.
    // multipleChoiceV2<>question<>OR<>Ccorrect option<>Wwrong option...
    private static func parse(_ source: String) -> [QuizQuestion] {
        let cleaned = source.replacingOccurrences(of: "\u{FEFF}", with: "")
        return cleaned.components(separatedBy: ">><<").compactMap { record in
            let fields = record.components(separatedBy: "<>")
            guard fields.first?.trimmingCharacters(in: .whitespacesAndNewlines) == "multipleChoiceV2",
                  fields.count >= 5 else { return nil }

            let questionText = fields[1].trimmingCharacters(in: .whitespacesAndNewlines)
            guard !questionText.isEmpty else { return nil }

            let options: [QuizOption] = fields.dropFirst(3).compactMap { field in
                guard let marker = field.first, marker == "C" || marker == "W" else { return nil }
                let optionText = String(field.dropFirst()).trimmingCharacters(in: .whitespacesAndNewlines)
                guard !optionText.isEmpty else { return nil }
                return QuizOption(text: optionText, isCorrect: marker == "C")
            }
            guard options.count >= 2, options.filter(\.isCorrect).count == 1 else { return nil }
            return QuizQuestion(text: questionText, options: options)
        }
    }
}
