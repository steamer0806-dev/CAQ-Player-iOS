import SwiftUI

@main
struct CAQPlayerApp: App {
    @StateObject private var store = QuizStore()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(store)
                .preferredColorScheme(.dark)
        }
    }
}
