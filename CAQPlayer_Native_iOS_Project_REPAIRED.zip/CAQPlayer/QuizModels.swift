import Foundation

struct QuizOption: Identifiable, Codable, Equatable {
    var id = UUID()
    let text: String
    let isCorrect: Bool
}

struct QuizQuestion: Identifiable, Codable, Equatable {
    var id = UUID()
    let text: String
    var options: [QuizOption]
}

struct QuizDocument: Codable {
    let fileName: String
    let questions: [QuizQuestion]
}

enum QuizImportError: LocalizedError {
    case missingQuestionFile
    case noQuestionsFound
    case malformedQuestion(String)

    var errorDescription: String? {
        switch self {
        case .missingQuestionFile:
            return "This file does not contain tempQuz.quz. Please choose a CAQ .quiz file."
        case .noQuestionsFound:
            return "No supported multiple-choice questions were found in this file."
        case .malformedQuestion(let detail):
            return "The quiz could not be read: \(detail)"
        }
    }
}
