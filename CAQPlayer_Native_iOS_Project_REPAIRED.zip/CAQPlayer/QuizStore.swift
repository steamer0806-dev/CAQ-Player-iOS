import Foundation
import SwiftUI
import AVFoundation

@MainActor
final class QuizStore: ObservableObject {
    @Published var document: QuizDocument?
    @Published var questions: [QuizQuestion] = []
    @Published var selectedAnswers: [Int?] = []
    @Published var currentIndex = 0
    @Published var isSubmitted = false
    @Published var errorMessage: String?
    @Published var speechEnabled = false
    @Published var speechRate: Float = 0.46

    private let synthesizer = AVSpeechSynthesizer()
    private let progressKey = "caq.native.progress"

    var currentQuestion: QuizQuestion? {
        guard questions.indices.contains(currentIndex) else { return nil }
        return questions[currentIndex]
    }

    var answeredCount: Int { selectedAnswers.compactMap { $0 }.count }

    var score: Int {
        questions.enumerated().reduce(0) { total, pair in
            let (index, question) = pair
            guard let answer = selectedAnswers[safe: index] ?? nil,
                  question.options.indices.contains(answer) else { return total }
            return total + (question.options[answer].isCorrect ? 1 : 0)
        }
    }

    func importQuiz(from url: URL) {
        do {
            let loaded = try CAQQuizImporter.load(from: url)
            document = loaded
            startNewAttempt()
            errorMessage = nil
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func startNewAttempt() {
        guard let document else { return }
        questions = document.questions.shuffled().map { question in
            QuizQuestion(text: question.text, options: question.options.shuffled())
        }
        selectedAnswers = Array(repeating: nil, count: questions.count)
        currentIndex = 0
        isSubmitted = false
        stopSpeaking()
        saveProgress()
    }

    func choose(_ optionIndex: Int) {
        guard !isSubmitted, selectedAnswers.indices.contains(currentIndex),
              selectedAnswers[currentIndex] == nil,
              currentQuestion?.options.indices.contains(optionIndex) == true else { return }
        selectedAnswers[currentIndex] = optionIndex
        saveProgress()
    }

    func next() {
        guard currentIndex + 1 < questions.count else { submit(); return }
        currentIndex += 1
        saveProgress()
        if speechEnabled { speakCurrentQuestion() }
    }

    func previous() {
        guard currentIndex > 0 else { return }
        currentIndex -= 1
        saveProgress()
        if speechEnabled { speakCurrentQuestion() }
    }

    func submit() {
        isSubmitted = true
        stopSpeaking()
        clearProgress()
    }

    func speakCurrentQuestion() {
        guard let q = currentQuestion else { return }
        synthesizer.stopSpeaking(at: .immediate)
        let phrases = ["Question \(currentIndex + 1).", q.text, "Here are the choices."]
            + q.options.enumerated().map { "Choice \(Character(UnicodeScalar(65 + $0.offset)!)). \($0.element.text)." }
        for (index, phrase) in phrases.enumerated() {
            let utterance = AVSpeechUtterance(string: phrase)
            utterance.rate = speechRate
            utterance.pitchMultiplier = 1.02
            utterance.preUtteranceDelay = index == 0 ? 0 : 0.28
            utterance.voice = AVSpeechSynthesisVoice(language: "en-PH")
                ?? AVSpeechSynthesisVoice(language: "en-US")
            synthesizer.speak(utterance)
        }
    }

    func stopSpeaking() { synthesizer.stopSpeaking(at: .immediate) }

    private func saveProgress() {
        guard document != nil else { return }
        let state = SavedProgress(fileName: document!.fileName, questions: questions,
                                  answers: selectedAnswers, index: currentIndex)
        if let data = try? JSONEncoder().encode(state) {
            UserDefaults.standard.set(data, forKey: progressKey)
        }
    }

    private func clearProgress() { UserDefaults.standard.removeObject(forKey: progressKey) }
}

private struct SavedProgress: Codable {
    let fileName: String
    let questions: [QuizQuestion]
    let answers: [Int?]
    let index: Int
}

private extension Collection {
    subscript(safe index: Index) -> Element? {
        indices.contains(index) ? self[index] : nil
    }
}
