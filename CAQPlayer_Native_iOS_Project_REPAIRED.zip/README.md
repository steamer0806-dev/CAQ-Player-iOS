# CAQ Player — Native iOS project

This is a native SwiftUI iPhone app project, not an HTML/PWA app.

## Features implemented
- Import `.quiz` files using the iOS Files document picker
- Read the CAQ ZIP archive's `tempQuz.quz` entry
- Parse `multipleChoiceV2` single-answer questions
- Shuffle question order and each question's answer options on every new attempt
- Speak questions and choices using iOS `AVSpeechSynthesizer`
- Show wrong selections in red and the correct answer in green
- Score, answer review, and retake with a new shuffle

## Important: installation requirements
This chat can generate the complete source project, but cannot sign and install a native iOS app onto your iPhone. Since you do not have a Mac, you need a cloud macOS build/signing service or help from someone with Xcode.

For personal installation on your own device:
1. Create an Apple ID if you do not already have one.
2. Use a cloud macOS build service that supports iOS code signing (for example, Codemagic) and connect this project through a private Git repository.
3. Configure signing with your Apple account/team. A free Apple Personal Team is normally limited and may require periodic reinstallation; paid Apple Developer Program membership is needed for TestFlight distribution.
4. Build an IPA and install it using the service's supported device-registration/install flow. Device registration and signing requirements apply.

This archive is a source project, not an IPA. No Apple credentials are included or requested here.

## Build in Xcode (if a Mac becomes available)
1. Create a new iOS App project named `CAQPlayer` using SwiftUI, minimum iOS 16.
2. Add the files in `CAQPlayer/` to the app target.
3. Add the Swift Package dependency `https://github.com/Weichsel/ZIPFoundation` (from 0.9.19).
4. Build and sign with your Apple Developer team.

## CAQ format assumptions
The importer expects a ZIP-based `.quiz` archive containing `tempQuz.quz`. Each question record is expected in the format:
`multipleChoiceV2<>question<>OR<>Ccorrect option<>Wwrong option...`
It requires exactly one option marked `C` per question. If your CAQ export uses a different variant, provide a sample file so the parser can be adapted.
